# APK 与签名说明

本目录下的 StudyGuard-v1.4.2.apk 是生产环境构建的 **debug 签名** 包，
签名证书：C=US, O=Android, CN=Android Debug（SHA-256: f2d644dc...e95c）

源码工程已附带新的固定 keystore（详见 ../android/keystore/）：
- debug.keystore           开发调试签名（别名 androiddebugkey / 密码 android）
- studyguard-release.jks   正式发布签名（别名 studyguard / 密码 StudyGuard@2026）
- keystore.properties      release 签名配置

⚠️ 签名已切换！旧用户安装新版（用新 keystore 构建的 APK）前需先卸载旧版，
否则会提示"应用未安装/签名不一致"。首次覆盖安装后，后续版本签名固定，
可正常升级，不再有冲突。
